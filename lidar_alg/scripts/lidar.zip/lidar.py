#!/usr/bin/env python3

import rospy
import numpy as np
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

class NodeLIDAR:
    def __init__(self):
        rospy.Subscriber('scan', LaserScan, self.lidar_callback)
        # rospy.Subscriber('/scan', LaserScan, self.lidar_callback)
        self.__vel_pub = rospy.Publisher('/jetauto_controller/cmd_vel', Twist, queue_size=10)
        
        self.a_vel  =    rospy.get_param("a_vel/val", default = 0.3)              #rotational velocity
        self.l_vel  =    rospy.get_param("l_vel/val", default = 0.15)              #rotational velocity
        self.kp     =    rospy.get_param("control/kp", default = 0.1)
        self.min_dist =  rospy.get_param("distance/min_dist", default = 0.3)          #minimum detected distance

        self.msg = Twist()

        self.count1 = 0
        self.count2 = 0

        self.rate = rospy.Rate(30)
    
    def adjust_velocity(self, linear_vel, angular_vel):
        # Apply speed limit to linear velocity
        # if linear_vel > 0.15:
        #     linear_vel = 0.15
        self.msg.linear.x = linear_vel
        self.msg.angular.z = angular_vel
        self.__vel_pub.publish(self.msg)
        self.rate.sleep()

    def move_forward(self, forward_distance):
        if forward_distance > self.min_dist:
            # linear_velocity = forward_distance * self.kp
            self.adjust_velocity(self.l_vel, 0)

    def turn_left(self):
        self.adjust_velocity(0, self.a_vel)

    def turn_right(self):
        self.adjust_velocity(0, -self.a_vel)
    
    def stop(self):
        self.adjust_velocity(0, 0)

    def navigate(self, forward_distance, left_distance, right_distance):
        if left_distance > right_distance:
            self.count1 += 1
            self.count2 = 0
            if self.count1 >= 15:
                self.turn_left()
                self.move_forward(forward_distance)
                self.count1 = 0
        elif left_distance < right_distance:
            self.count2 += 1
            self.count1 = 0
            if self.count2 >= 15:
                self.turn_right()
                self.move_forward(forward_distance)
                self.count2 = 0
        else:
            self.move_forward(forward_distance)

    def lidar_callback(self, data):
    
        forward_distance =  min(data.ranges[0:144] + data.ranges[1004:1147])
        left_distance =     min(data.ranges[144:287])
        right_distance =    min(data.ranges[861:1004])

        # if forward_distance > self.min_dist and left_distance > self.min_dist and right_distance > self.min_dist:
        #     print("forward")
        #     self.move_forward(forward_distance)
        # elif forward_distance < self.min_dist and left_distance < self.min_dist and right_distance > self.min_dist:
        #     print("right")
        #     self.turn_right()
        # elif forward_distance < self.min_dist and left_distance > self.min_dist and right_distance < self.min_dist:
        #     print("left")
        #     self.turn_left()
        # else:
        #     print("navigate")
        #     self.navigate(forward_distance, left_distance, right_distance)

        if forward_distance > self.min_dist:
            if right_distance > 2*forward_distance:
                print("RIGHT")
                self.turn_right()
            else:
                print("forward")
                self.move_forward(forward_distance)
        elif right_distance > left_distance:
            print("right")
            self.turn_right()   
        elif left_distance > right_distance:
            print("left")
            self.turn_left()

if __name__ == '__main__':
    rospy.init_node('obstacle_avoidance_node')
    node_handler = NodeLIDAR()
    rospy.spin()